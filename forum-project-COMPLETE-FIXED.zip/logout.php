<?php
/**
 * Forum Project - Logout
 * Free Hosting Optimized
 */

session_start();
logout_user();
?>