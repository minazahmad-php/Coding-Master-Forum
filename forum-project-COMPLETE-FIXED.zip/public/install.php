<?php
/**
 * Public Install Entry Point
 * Redirects to main install.php
 */

header('Location: ../install.php');
exit;