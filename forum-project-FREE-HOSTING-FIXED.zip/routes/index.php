<?php
declare(strict_types=1);

// Routes Index - Load all route files
require_once __DIR__ . '/web.php';
require_once __DIR__ . '/api.php';